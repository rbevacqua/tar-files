
#include <signal.h>
#include <assert.h>
#include "sr_nat.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "sr_if.h"
#include "sr_rt.h"
#include "sr_router.h"
#include "sr_arpcache.h"
#include "sr_utils.h"

int sr_nat_init(struct sr_nat *nat) { /* Initializes the nat */

  assert(nat);

  /* Acquire mutex lock */
  pthread_mutexattr_init(&(nat->attr));
  pthread_mutexattr_settype(&(nat->attr), PTHREAD_MUTEX_RECURSIVE);
  int success = pthread_mutex_init(&(nat->lock), &(nat->attr));

  /* Initialize timeout thread */

  pthread_attr_init(&(nat->thread_attr));
  pthread_attr_setdetachstate(&(nat->thread_attr), PTHREAD_CREATE_JOINABLE);
  pthread_attr_setscope(&(nat->thread_attr), PTHREAD_SCOPE_SYSTEM);
  pthread_attr_setscope(&(nat->thread_attr), PTHREAD_SCOPE_SYSTEM);
  pthread_create(&(nat->thread), &(nat->thread_attr), sr_nat_timeout, nat);

  /* CAREFUL MODIFYING CODE ABOVE THIS LINE! */

  nat->mappings = NULL;
  /* Initialize any variables here */
  
  nat->incoming = NULL;
  nat->nextPort = 1024;

  return success;
}


int sr_nat_destroy(struct sr_nat *nat) {  /* Destroys the nat (free memory) */

  pthread_mutex_lock(&(nat->lock));

  /* free nat memory here */
  
  struct sr_nat_mapping *current = nat->mappings;
  struct sr_nat_mapping *previous_map = NULL;
  while (current != NULL) {
	   previous_map = current;
	  current = current->next;
	  free(previous_map);
  }
  
  struct sr_tcp_syn *incoming = nat->incoming;
  struct sr_tcp_syn *previous = NULL;
  while (incoming != NULL) {
	  previous = incoming;
	  incoming = incoming->next;
	  free(previous);
  }

  pthread_kill(nat->thread, SIGKILL);
  return pthread_mutex_destroy(&(nat->lock)) &&
    pthread_mutexattr_destroy(&(nat->attr));

}

void *sr_nat_timeout(void *nat_ptr) {  /* Periodic Timout handling */
	
  struct sr_nat *nat = (struct sr_nat *)nat_ptr;
  while (1) {
    sleep(1.0);
    pthread_mutex_lock(&(nat->lock));

    time_t curtime = time(NULL);

    /* handle periodic tasks here */
    
    /*Incoming SYN timeout*/
    struct sr_tcp_syn *incoming = nat->incoming;
    struct sr_tcp_syn *prev = NULL;
    while (incoming != NULL) {
    	if (difftime(curtime, incoming->arrived) >= 6) {
    		/*Timeout exceeded. Sending ICMP port unreachable*/
    		sr_send_icmp(nat->sr, incoming->data, incoming->interface, 3, 3);
    		
    		if (prev == NULL) {
    			nat->incoming = incoming->next;
    		} else {
    			prev->next = incoming->next;
    		}
    		
    		struct sr_tcp_syn *temp = incoming;
    		incoming = incoming->next;
    		free(temp->data);
    		free(temp);
    	} else {
    		prev = incoming;
    		incoming = incoming->next;
    	}
    }
    
    /*NAT MAPPING TIMEOUT*/
    struct sr_nat_mapping *map = nat->mappings;
    struct sr_nat_mapping *prev_map = NULL;
    
    while (map != NULL) {
    	int map_timeout = 0;
    	
    	if (map->type == nat_mapping_icmp) {
    		int diff = difftime(curtime, map->last_updated);
    		
    		map_timeout = diff >= (nat->icmpTimeout);
    		
    	}
    	
    	if (map->type == nat_mapping_tcp) {
    		struct sr_nat_connection *connect = map->conns;
    		struct sr_nat_connection *prev_connect = NULL;
    		
    		while (connect != NULL) {
    			int diff = difftime(curtime, connect->update_time);
    			int connect_timeout = 0;
    			
    			if (connect->int_syn && connect->ext_syn && !(connect->int_fin) && !(connect->ext_fin)) {
    				connect_timeout = diff >= nat->tcpEstTimeout;
    						
    			} else {
    				connect_timeout = diff >= nat->tcpTransTimeout;
    			}
    			
    			if (connect_timeout) {
    				/*Remove Connection*/
    				
    				if (prev_connect == NULL) {
    					map->conns = connect->next;
    				} else {
    					prev_connect->next = connect->next;
    				}
    				
    				struct sr_nat_connection *temp = connect;
    				connect = connect->next;
    				free(temp);
    				
    				/*can remove mapping if there are no more connections*/
    				map_timeout = map->conns == NULL;
    				
    			} else {
    				prev_connect = connect;
    				connect = connect->next;
    				
    			}
    			
    			
    		}
    		
    	}
    
		/*IF mapping timeout exceeded, remove it */
		
		if (map_timeout) {
			if (prev_map == NULL) {
				nat->mappings = map->next;
			} else {
				prev_map->next = map->next;
			}
			
			struct sr_nat_mapping *temp = map;
			map = map->next;
			free(temp);
			
		} else {
			prev_map = map;
			map = map->next;
		}
    
    }
    
    pthread_mutex_unlock(&(nat->lock));
  }
  return NULL;
}

/* Get the mapping associated with given external port.
   You must free the returned structure if it is not NULL. */
struct sr_nat_mapping *sr_nat_lookup_external(struct sr_nat *nat,
    uint16_t aux_ext, sr_nat_mapping_type type ) {

  pthread_mutex_lock(&(nat->lock));

  /* handle lookup here, malloc and assign to copy */
  struct sr_nat_mapping *copy = NULL;
  struct sr_nat_mapping *current = nat->mappings;
  
  while (current != NULL) {
	  if (current->aux_ext == aux_ext && current->type == type) {
		  /*Found the mapping we are searching for*/
		  current->last_updated = time(NULL);
		  copy = malloc(sizeof(struct sr_nat_mapping));
		  memcpy(copy, current, sizeof(struct sr_nat_mapping));
		  break;
	  }
	  
	  current = current->next;
  }

  pthread_mutex_unlock(&(nat->lock));
  return copy;
}

/* Get the mapping associated with given internal (ip, port) pair.
   You must free the returned structure if it is not NULL. */
struct sr_nat_mapping *sr_nat_lookup_internal(struct sr_nat *nat,
  uint32_t ip_int, uint16_t aux_int, sr_nat_mapping_type type ) {

  pthread_mutex_lock(&(nat->lock));

  /* handle lookup here, malloc and assign to copy. */
  struct sr_nat_mapping *copy = NULL;
  struct sr_nat_mapping *current = nat->mappings;
  
  while (current != NULL) {
	  if (current->ip_int == ip_int && current->aux_int == aux_int && current->type == type) {
		  /* Found Mapping */
		  
		  current->last_updated = time(NULL);
		  copy = malloc(sizeof(struct sr_nat_mapping));
		  memcpy(copy, current, sizeof(struct sr_nat_mapping));
		  
		  break;
	  }
	  
	  current = current->next;
  }

  pthread_mutex_unlock(&(nat->lock));
  return copy;
}

/* Insert a new mapping into the nat's mapping table.
   Actually returns a copy to the new mapping, for thread safety.
 */
struct sr_nat_mapping *sr_nat_insert_mapping(struct sr_nat *nat,
  uint32_t ip_int, uint16_t aux_int, sr_nat_mapping_type type ) {
	
  pthread_mutex_lock(&(nat->lock));

  /* handle insert here, create a mapping, and then return a copy of it */
  struct sr_nat_mapping *mapping = (struct sr_nat_mapping *) malloc(sizeof(struct sr_nat_mapping));
  struct sr_nat_mapping *new_map = (struct sr_nat_mapping *) malloc(sizeof(struct sr_nat_mapping));
  struct sr_if *ext_if = sr_get_interface(nat->sr, "eth2");
  
  new_map->type = type;
  new_map->ip_int = ip_int;
  new_map->ip_ext = ext_if->ip;
  new_map->aux_int = aux_int;
  
  new_map->last_updated = time(NULL);
  new_map->conns = NULL;
  
  new_map->aux_ext = htons(nat->nextPort);
  nat->nextPort = nat->nextPort + 1;
  
  if (nat->nextPort >= 65535) {
	  /*Max port number reached, restart cycle*/
	  nat->nextPort = 1024;
  }
  
  /*Insert mapping as head of the list*/
  new_map->next = nat->mappings;
  nat->mappings = new_map;
  
  memcpy(mapping, new_map, sizeof(struct sr_nat_mapping));

  pthread_mutex_unlock(&(nat->lock));
  return mapping;
}

int sr_nat_translate(struct sr_instance* sr,
		uint8_t * packet, unsigned int len, char* interface) {
	
	
	struct sr_ip_hdr *ip_pkt = (struct sr_ip_hdr *) (packet + sizeof(struct sr_ethernet_hdr));
	
	pkt_dir dir = get_pkt_direction(sr, ip_pkt);
	
	uint8_t ip_protocol = ip_pkt->ip_p;
	
	if (ip_protocol != ip_protocol_icmp && ip_protocol != ip_protocol_tcp) {
		/*Drop packet*/
		return 1;
	}
	
	if (dir == dir_notCrossing) {
		/*does not need to be translated*/
		return 0;
	}
	
	if (dir == dir_blocked) {
		return 1;
	}
	
	struct sr_nat_mapping *map = sr_nat_get_mapping_pkt(sr, packet, len, interface, dir);
	
	if (map == NULL) {
		if (ip_protocol == ip_protocol_icmp) {
			
			return 0;
		} else if (ip_protocol == ip_protocol_tcp) {
			
			return 1;
		}
	}
	
	if (map->type == nat_mapping_tcp) {
		sr_nat_update_tcp_conn(sr, packet, map, dir);
	}
	
	if (ip_protocol == ip_protocol_icmp) {
		sr_icmp_hdr_t *icmp_pkt = (sr_icmp_hdr_t *) (packet + sizeof(struct sr_ethernet_hdr) + sizeof(struct sr_ip_hdr));
		
		if (dir == dir_incoming) {
			ip_pkt->ip_dst = map->ip_int;
			icmp_pkt->icmp_identifier = map->aux_int;
			
		} else if (dir == dir_outgoing) {
			ip_pkt->ip_src = map->ip_ext;
			icmp_pkt->icmp_identifier = map->aux_ext;
		}
		
		if (icmp_pkt->icmp_type == 3) {
			icmp_pkt->icmp_sum = 0;
			icmp_pkt->icmp_sum = cksum(icmp_pkt, len - sizeof(struct sr_ip_hdr) - sizeof(struct sr_ethernet_hdr));
		} else {
			icmp_pkt->icmp_sum = 0;
			icmp_pkt->icmp_sum = cksum(icmp_pkt, len - sizeof(struct sr_ip_hdr) - sizeof(struct sr_ethernet_hdr));
		}
		
	} else if (ip_protocol == ip_protocol_tcp) {
		sr_tcp_hdr_t *tcp_pkt = (sr_tcp_hdr_t *) (packet + sizeof(struct sr_ethernet_hdr) + sizeof(struct sr_ip_hdr));
		
		if (dir == dir_incoming) {
			ip_pkt->ip_dst = map->ip_int;
			tcp_pkt->port_dst = map->aux_int;
			
		} else if (dir == dir_outgoing) {
			ip_pkt->ip_src = map->ip_ext;
			tcp_pkt->port_src = map->aux_ext;
		}
		
		tcp_pkt->sum = tcp_cksum(packet, len);
		
	}
	
	ip_pkt->ip_sum = 0;
	ip_pkt->ip_sum = cksum(ip_pkt, sizeof(sr_ip_hdr_t));
	
	free(map);
	
	return 0;
}

void sr_nat_update_tcp_conn(struct sr_instance *sr, uint8_t *packet, struct sr_nat_mapping *map, pkt_dir dir) {

	struct sr_nat *nat = sr->nat;
	sr_ip_hdr_t *ip_pkt = (sr_ip_hdr_t *) (packet + sizeof(struct sr_ethernet_hdr));
	sr_tcp_hdr_t *tcp_pkt = (sr_tcp_hdr_t *) (packet + sizeof(struct sr_ethernet_hdr) + sizeof(struct sr_ip_hdr));
	
	pthread_mutex_lock(&(nat->lock));
	
	uint32_t ip;
	uint16_t port;
	
	/*find external*/
	
	if (dir == dir_incoming) {
		ip = ip_pkt->ip_src;
		port = tcp_pkt->port_src;
		
	} else if (dir == dir_outgoing) {
		ip = ip_pkt->ip_dst;
		port = tcp_pkt->port_dst;
	} else {
		printf("Error in updateing tcp connection\n");
		return;
	} 
	
	/*get mapping*/
	
	struct sr_nat_mapping *prev_map = NULL;
	struct sr_nat_mapping *curr = nat->mappings;
	
	while (curr != NULL) {
		if (curr->ip_int == map->ip_int && curr->aux_int == map->aux_int && curr->type == map->type) {
			map = curr;
			break;
		}
		prev_map = curr;
		curr = curr->next;
		
	}
	
	if (curr == NULL) {
		/*Did not Find the Mapping*/
		printf("Mapping Not Found");
	}
	
	/*Get connection if it exists or create new one if it doesn't*/
	struct sr_nat_connection *conn = map->conns;
	struct sr_nat_connection *prev_conn = NULL;
	
	while (conn != NULL) {
		if (conn->ext_ip == ip && conn->ext_port) {
			break;
		}
		
		prev_conn = conn;
		conn = conn->next;
		
	}
	
	/*Create new connection here*/
	if (conn == NULL) {
		conn = (struct sr_nat_connection *) malloc(sizeof(struct sr_nat_connection));
				conn->ext_ip = ip;
				conn->ext_port = port;
				conn->ext_syn = 0;
				conn->ext_fin = 0;
				conn->ext_fack = 0;
				conn->int_syn = 0;	
				conn->int_fin = 0;	
				conn->int_fack = 0;	
				conn->int_fin_seqnum = 0;
				conn->ext_fin_seqnum = 0;
				conn->next = map->conns;
				
				/*add new connection to mapping entry*/
				map->conns = conn;
	}
	
	conn->update_time = time(NULL);
	
	if (dir == dir_incoming) {
		if (tcp_pkt->flags & TCP_FIN) {
			conn->ext_fin_seqnum = ntohl(tcp_pkt->seq_num);
		}
		
		conn->ext_syn = conn->ext_syn || (tcp_pkt->flags & TCP_SYN);
		conn->ext_fin = conn->ext_fin || (tcp_pkt->flags & TCP_FIN);
		conn->ext_fack = conn->ext_fack || (conn->int_fin && (conn->int_fin_seqnum < ntohl(tcp_pkt->ack_num)));
		
	} else if (dir == dir_outgoing) {
		if (tcp_pkt->flags & TCP_FIN) {
			conn->int_fin_seqnum = ntohl(tcp_pkt->seq_num);
		}
		
		conn->int_syn = conn->int_syn || (tcp_pkt->flags & TCP_SYN);
		conn->int_fin = conn->int_fin || (tcp_pkt->flags & TCP_FIN);
		conn->int_fack = conn->int_fack || (conn->ext_fin && (conn->ext_fin_seqnum < ntohl(tcp_pkt->ack_num)));
		
	} else {
		printf("Error during TCP Syncing Process");
		return;
	}
	
	/*check if connection needs to close*/
	if ((tcp_pkt->flags & TCP_RST) || (conn->int_fack && conn->ext_fack)) {
		/*Remove the connection from the map*/
		if (prev_conn == NULL) {
			map->conns = conn->next;
		} else {
			prev_conn->next = conn->next;
		}
		free(conn);
		
		/*clean up map if necessary*/
		if (map->conns == NULL) {
			if (prev_map == NULL) {
				nat->mappings = map->next;
			} else {
				prev_map->next = map->next;
			}
			
			free(map);
		}
	}
	
	pthread_mutex_unlock(&(nat->lock));
	
	
}

struct sr_nat_mapping *sr_nat_get_mapping_pkt(struct sr_instance* sr, 
	uint8_t *packet, unsigned int len, char* interface, pkt_dir dir) {
	
	struct sr_ip_hdr *ip_pkt = (struct sr_ip_hdr *) (packet + sizeof(struct sr_ethernet_hdr));
	
	struct sr_nat_mapping *map = NULL;
	
	uint16_t port = 0;
	sr_nat_mapping_type map_type = 0;
	
	/*Get type and port from packet*/
	
	if (ip_pkt->ip_p == ip_protocol_icmp) {
		sr_icmp_hdr_t *icmp_pkt = (sr_icmp_hdr_t *) (packet + sizeof(struct sr_ethernet_hdr) + sizeof(struct sr_ip_hdr));
		map_type = nat_mapping_icmp;
		port = icmp_pkt->icmp_identifier;
		
	} else if (ip_protocol_tcp) {
		sr_tcp_hdr_t *tcp_pkt = (sr_tcp_hdr_t *) (packet + sizeof(struct sr_ethernet_hdr) + sizeof(struct sr_ip_hdr));
		map_type = nat_mapping_tcp;
		if (dir == dir_incoming) {
			port = tcp_pkt->port_dst;
			
		} else if (dir == dir_outgoing) {
			port = tcp_pkt->port_src;
		}
		
	}
	
	/*Get map based on direction*/
	if (dir == dir_incoming) {
		map = sr_nat_lookup_external(sr->nat, port, map_type);
		
		if (map == NULL) {
			
			if (map_type == nat_mapping_tcp) {
				sr_tcp_hdr_t *tcp = (sr_tcp_hdr_t *) (packet + sizeof(struct sr_ethernet_hdr) + sizeof(struct sr_ip_hdr));
				
				/*Queue incoming TCP SYN packets*/
				if (tcp->flags & TCP_SYN) {
					
					pthread_mutex_lock(&(sr->nat->lock));
					
					struct sr_tcp_syn *in = sr->nat->incoming;
					
					while (in != NULL) {
						if ((in->ip_src == ip_pkt->ip_src) && (in->port_src == tcp->port_src)) {
							break;
						}
						
						in = in->next;
						
					}
					
					if (in == NULL) {
						struct sr_tcp_syn *new_tcp = (struct sr_tcp_syn *) malloc(sizeof(struct sr_tcp_syn));
						
						new_tcp->ip_src = ip_pkt->ip_src;
						new_tcp->port_src = tcp->port_src;
						new_tcp->arrived = time(NULL);
						new_tcp->len = len;
						new_tcp->interface = interface;
						new_tcp->data = (uint8_t *) malloc(len);
						memcpy(new_tcp->data, packet, len);
						
						new_tcp->next = sr->nat->incoming;
						sr->nat->incoming = new_tcp;
					}
					
					pthread_mutex_unlock(&(sr->nat->lock));
				}
			}
		}
	} else if (dir == dir_outgoing) {
		map = sr_nat_lookup_internal(sr->nat, ip_pkt->ip_src, port, map_type);
		
		if (map == NULL) {
			
			if (map_type == nat_mapping_tcp) {
				sr_tcp_hdr_t *tcp = (sr_tcp_hdr_t *) (packet + sizeof(struct sr_ethernet_hdr) + sizeof(struct sr_ip_hdr));
				
				if (tcp->flags & TCP_SYN) {
					pthread_mutex_lock(&(sr->nat->lock));
					
					struct sr_tcp_syn *in = sr->nat->incoming;
					struct sr_tcp_syn *prev_in = NULL;
					
					while (in != NULL) {
						if ((in->ip_src == ip_pkt->ip_dst) && (in->port_src == tcp->port_dst)) {
							
							if (prev_in != NULL) {
								prev_in->next = in->next;
								
							} else {
								sr->nat->incoming = in->next;
							}
							
							break;
						}
						
						prev_in = in;
						in = in->next;
					}
					
					pthread_mutex_unlock(&(sr->nat->lock));
					
				} else {
					return NULL;
				}
			}
			
			map = sr_nat_insert_mapping(sr->nat, ip_pkt->ip_src, port, map_type);
			
		}
		
	} else {
		
		printf("Error in retrieving map from packet");
		
	}
	
	return map;
}

pkt_dir get_pkt_direction(struct sr_instance* sr, struct sr_ip_hdr *ip_pkt) {
	int int_src = is_ip_within_nat(sr, ip_pkt->ip_src);
	int int_dst = is_ip_within_nat(sr, ip_pkt->ip_dst);
	
	struct sr_if *eth2_if = sr_get_interface(sr, "eth2");
	
	int dst_is_nat = ip_pkt->ip_dst == eth2_if->ip;
	
	if (!int_src && dst_is_nat) {
		return dir_incoming;
	}
	
	if (int_dst < 0) {
		return dir_notCrossing;
	}
	
	if (!int_src && int_dst) {
		return dir_blocked;
	}
	
	if (int_src && !int_dst) {
		return dir_outgoing;
	}
	
	return dir_notCrossing;
}

int is_ip_within_nat(struct sr_instance *sr, uint32_t ip) {
	struct sr_rt *lpm = longest_prefix_match(sr, ip);
	if (lpm == NULL) {
		return -1;
		
	} else {
		if (strncmp(lpm->interface, "eth1", 4) == 0) {
			return 1;
		}
	}
	
	return 0;
}
