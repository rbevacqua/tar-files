*** Overview of Code Structure ***

most of the added functions were placed in router.c

First we have the sr_handlepacket which determines if the packet is an ARP packet or IP Packet
If its an ARP then sr_arp_handler is called and if Its an IP packet then the
sr_ip_handler is called instead.

So continuing if the the Packet is an ARP, then sr_arp_handler will determine
if the ARP Packet is a Reply or Request if it is a Request then the function 
will call sr_send_arp to send a reply back to the sender. However if it is a reply
then we insert the new IP-MAC mapping into the cache and retrieve the corresponding 
request queue and send all packets attached to that request along the MAC address that 
was sent with the reply.

Now we will look at how the source code will progress if we received a IP packet.
So sr_ip_handler will determine if the IP is destined towards one of the router's IPs
or somewhere else. If it is not for our router than we will forward the packet by calling 
forward_pkt which in the end will forward the packet if it finds an arp entry in the cache else
it will have be place in the request queue and wait for an ARP REPLY, which is handled by the function
handle_arpreq which sends a max of 5 ARP Requests before it sends an ICMP back to all packet senders
in the queue.If instead it is destined for one of our router's interfaces then icmp_handler is called.

If icmp_handler is called then this function will determine if the IP Packet is an ICMP Echo Request 
or TCP or UDP. If its a TCP or UDP protocol implemented packet then an ICMP is sent back to the sender 
of the packet. If it isn't then we send an ICMP echo reply back to sender.

longest_prefix_match retrieves a routing table entry that contains the Next-Hop IP for a given destination IP
get_interface_by_ip retrieves a interface record that contains the given ip

handle_arpreq is in the arpcache.c file. This function just manages sending ARP requests every second and 
checking if an ICMP "host unreachable" packet should be sent. 

*** Ambiguities ***
There was some ambiguity in whether another arpcache lookup should occur every
time an ICMP is sent back to the sender, however I decided that it wasn't required 
since the needed information to send it back to the sender was already aquired.   
