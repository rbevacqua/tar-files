#include <cstdio>
#include <iostream>
#include <string>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <sstream>
#include <sys/time.h>
#include <ios>
#include <vector>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <malloc.h>

using namespace std;



typedef struct record {
	
	int uid1;

	int uid2;

} Record;

string* line_parser(string);
vector<Record> read_file(char *, long*);
vector<string> read_file_lines(char *, long *);