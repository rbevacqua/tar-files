#include "utils.h"

string * line_parser(string line) {

	string * result = new string [2];
	stringstream ss(line);

	getline(ss, result[0], ',');
	getline(ss, result[1], ',');

	return result;

}

vector<Record> read_file(char * filename, long *size) {

	ifstream infile(filename);
	string line;

	if (!infile) {
		printf("Error opening up file\n");
		exit(-1);
	}

	vector<Record> records;

	while (getline(infile, line)) {
		string *i = line_parser(line);

		Record r;

		r.uid1 = atoi(i[0].data());
		r.uid2 = atoi(i[1].data());

		/*fill up the the vector object*/

		records.push_back(r);

		delete[] i;
	}

	*size = records.size();

	infile.close();

	return records;
}

vector<string> read_file_lines(char * filename, long *size) {

	ifstream infile(filename);
	string line;

	if (!infile) {
		printf("Error opening up file\n");
		exit(-1);
	}

	vector<string> records;

	while (getline(infile, line)) {

		records.push_back(line);

	}
	
	*size = records.size();

	infile.close();

	return records;
}