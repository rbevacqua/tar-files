declare -i KB
declare -i MB
declare -a SIZE

echo "MakeFile Result:" > results.txt
make -f Makefile >> results.txt

FILE="edges.csv"
KB=1024
MB=$((1024*1024))
SIZE=(512 $((1*$KB)) $((4*$KB)) $((8*$KB)) $((16*$KB)) $((32*$KB)) $((1*$MB)) $((2*$MB)) $((4*$MB)))

echo "" >> results.txt

echo "Starting write_blocks Program..."

echo "write_blocks Results (multiple block sizes in BYTES)" >> results.txt

for s in "${SIZE[@]}"
do
	rm "edges.dat" 2>/dev/null

	echo "----------------------------------" >> results.txt

	bs="BLOCK-SIZE: "
	bs+=$s

	echo $bs >> results.txt

	./write_blocks $FILE $s >> results.txt

done

echo "write_blocks Program Finished, Now Starting write_lines Program ..."

printf "\n\n" >> results.txt

echo "write_lines Results" >> results.txt

echo "----------------------------------" >> results.txt

echo "" >> results.txt

./write_lines $FILE >> results.txt

printf "\n\n" >> results.txt

echo "write_lines Program Finished, Now Starting max_ave_seq_disk Program"

echo " max_ave_seq_disk Results" >> results.txt

echo "----------------------------------" >> results.txt

echo "" >> results.txt

./max_ave_seq_disk "edges.dat" >> results.txt

rm "edges.dat" 2>/dev/null

printf "\n\n" >> results.txt

echo  "max_ave_seq_disk Program Finished, Now Starting max_ave_seq_ram Program"

./write_blocks $FILE 4096 1> /dev/null

echo " max_ave_seq_ram Results" >> results.txt

echo "----------------------------------" >> results.txt

echo "" >> results.txt

./max_ave_seq_ram "edges.dat" >> results.txt