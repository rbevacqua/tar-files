#include "utils.h"

int main(int argc, char* argv[]) {

	if (argc != 2) {
		printf("not the right amount of arguments\n");
		exit(-1);
	}

	int fd = open("edges.txt", O_WRONLY | O_CREAT, 0666);

	/*Timer variables intialization*/
	struct timeval start, end;
	double time_spent;
	long total_records = 0;

	int bytes = 0;

	/*other allocated variables*/
	int num_records; 
	
	vector<string> lines = read_file_lines(argv[1], &total_records);

	num_records = 0;

	string *i;

	gettimeofday(&start, NULL);

	

	while(num_records != total_records) {

		i = &lines[num_records];
		(*i) += '\n';

		write(fd, i->c_str(), i->size());
		

		bytes += i->size();

		num_records++;
	}

	fsync(fd);

	gettimeofday(&end, NULL);

	time_spent = (double)(end.tv_sec - start.tv_sec) + (double)(end.tv_usec - start.tv_usec)/1000000;

	close(fd);

	printf ("Data rate: %.3f BPS\n", (bytes/time_spent));

	return 0;
}