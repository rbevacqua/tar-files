#include "utils.h"

int main(int argc, char *argv[]) {
	
	int block_size;
	int records_in_buff;
	int i;
	char *filename;

	/* This clears linux caches*/
	sync();
	ofstream ofs("/proc/sys/vm/drop_caches");
	ofs << "3" << endl;

	/*Timer variables intialization*/
	struct timeval start, end;
	double time_spent;
	int total_records = 0;

	if (argc > 3) {
		printf("not the correct number of arguments were given");
		exit(-1);
	} else if (argc == 3) {
		block_size = atoi(argv[2]);
		filename = argv[1];
	} else {
		block_size = (1024 * 1024); /*default blocksize*/
		filename = argv[1];
	}

	int max = 0;
	int temp_max = 0;
	int curr_uid = -1;
	int sum = 0;
	int total_uids = 0;
	int fd = open(filename, O_RDONLY);
	int bytes_read;

	/*buffer that is used to process individual blocks of Records*/
	Record * buffer;

	posix_memalign((void **)&buffer, 512, block_size);

	gettimeofday(&start, NULL);

	while((bytes_read = read(fd, (void *)buffer, block_size)) != 0) {
		/*Read Blocks of Records directly from input file on disk*/

		records_in_buff = bytes_read/sizeof(Record);
		
		total_records += records_in_buff;
		
		for (i=0; i<records_in_buff; i++) {
			if (curr_uid != buffer[i].uid1) {
				if (max < temp_max) {
					max = temp_max;
					
				} 

				temp_max = 0;
				curr_uid = buffer[i].uid1;
				total_uids++;

			} 

			sum++;
			temp_max++;

			
		}

	}

	gettimeofday(&end, NULL);

	free(buffer);

	cout << "Average:" << (double)sum/total_uids << '\n';
	cout << "MAX:" << max << endl;
	
	close(fd);
	
	time_spent = (double)(end.tv_sec - start.tv_sec) + (double)(end.tv_usec - start.tv_usec)/1000000;
	
	printf ("Data rate: %.3f BPS\n", ((total_records*sizeof(Record))/time_spent));

	return 0;
}