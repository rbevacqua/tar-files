#include "utils.h"

int main(int argc, char* argv[]) {

	if (argc != 3) {
		printf("not the right amount of arguments\n");
		exit(-1);
	}

	int block_size = atoi(argv[2]);
	int fd = open("edges.dat", O_WRONLY | O_DIRECT | O_CREAT, 0666);

	/*Timer variables intialization*/
	struct timeval start, end;
	double time_spent = 0.0;
	long total_records = 0;

	/*determine records per blocksize*/

	int records_per_block = block_size/sizeof(Record);

	/*other allocated variables*/
	int num_records; 
	int records_written = 0;


	vector<Record> records = read_file(argv[1], &total_records);

	num_records = total_records;

	Record * buffer;
	Record * buf;
	

	posix_memalign((void**)&buf, 512, block_size);

	
	
	/*writing begins here , everything is allocated before in order
		to try to get an accurate BPS rate for writing in blocks only*/
	
	while (num_records != 0) {

		/*buffer points to next block to be written to records.dat*/
		
		buffer = &records[records_written];

		if (num_records >= records_per_block) {
			memcpy(buf, buffer, block_size);
			/*flush buffer to the binary file records.dat*/

			gettimeofday(&start, NULL);

			write(fd, (const void *)buf, block_size);

			gettimeofday(&end, NULL);

			time_spent += (double)(end.tv_sec - start.tv_sec) + (double)(end.tv_usec - start.tv_usec)/1000000;
			

			num_records -= records_per_block;
			records_written += records_per_block;

		}else {

			memcpy(buf, buffer, num_records*sizeof(Record));
			
			/*Used to turn off O_DIRECT FLAG for last write of the file*/
			int val = fcntl(fd, F_GETFL, 0);

			val &= ~O_DIRECT;

			fcntl(fd, F_SETFL, val);

			/*This makes sure that if the last block didn't fill up 
		 the remaining records are written to the edges.dat file*/

			gettimeofday(&start, NULL);

			write(fd, (char *)buf, num_records*sizeof(Record));

			gettimeofday(&end, NULL);

			time_spent += (double)(end.tv_sec - start.tv_sec) + (double)(end.tv_usec - start.tv_usec)/1000000;
			
			num_records = 0;
		
		}

	}

	gettimeofday(&start, NULL);

	fsync(fd);

	gettimeofday(&end, NULL);

	free(buf);

	time_spent += (double)(end.tv_sec - start.tv_sec) + (double)(end.tv_usec - start.tv_usec)/1000000;

	close(fd);
	
	printf ("Data rate: %.3f BPS\n", ((total_records*sizeof(Record))/time_spent));

	return 0;
}