#include "utils.h"

int main(int argc, char *argv[]) {

	/* This clears linux caches*/
	sync();
	ofstream ofs("/proc/sys/vm/drop_caches");
	ofs << "3" << endl;
	
	int block_size;
	int records_in_buff;
	int i;
	char *filename;
	

	if (argc > 3) {
		printf("not the correct number of arguments were given");
		exit(-1);
	} else if (argc == 3) {
		block_size = atoi(argv[2]);
		filename = argv[1];
	} else {
		block_size = (1024 * 1024); /*default blocksize*/
		filename = argv[1];
	}

	/*Timer variables intialization*/
	struct timeval start, end;
	double time_spent;

	int records_per_block = block_size/sizeof(Record);
	int max = 0;
	int temp_max = 0;
	int curr_uid = -1;
	int sum = 0;
	int total_uids = 0;
	ifstream infile(filename);

	infile.seekg(0, infile.end);
	int length = infile.tellg();
	infile.seekg(0, infile.beg);

	/*Place contents of the entire file in main memory*/
	char *memory = new char [length];

	infile.read(memory, length);

	/*buffer that is used to process individual blocks of Records*/
	Record * buffer;

	long total_records = length/sizeof(Record);
	length = total_records;
	int records_read = 0;

	gettimeofday(&start, NULL);

	while(records_read != total_records) {
		/*Read Blocks of Records directly from input file on disk*/

		int l = records_read * sizeof(Record);
		buffer = (Record *)&memory[l];
		
		if (length < records_per_block) {
			records_in_buff = length;
			length = 0;
			records_read = total_records;

		} else {
			records_in_buff = records_per_block;
			length -= records_per_block;
			records_read += records_per_block;
		}

		
		for (i=0; i<records_in_buff; i++) {
			if (curr_uid != buffer[i].uid1) {
				if (max < temp_max) {
					max = temp_max;
				} 

				temp_max = 0;
				curr_uid = buffer[i].uid1;
				total_uids++;

			} 

			sum++;
			temp_max++;

			
		}

	}

	gettimeofday(&end, NULL);

	delete[] memory;

	infile.close();

	cout << "Average:" << (double)sum/total_uids << '\n';
	cout << "MAX:" << max << endl;

	time_spent = (double)(end.tv_sec - start.tv_sec) + (double)(end.tv_usec - start.tv_usec)/1000000;

	printf ("Data rate: %.3f BPS\n", ((total_records*sizeof(Record))/time_spent));

	return 0;
}