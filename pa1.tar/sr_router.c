/**********************************************************************
 * file:  sr_router.c
 * date:  Mon Feb 18 12:50:42 PST 2002
 * Contact: casado@stanford.edu
 *
 * Description:
 *
 * This file contains all the functions that interact directly
 * with the routing table, as well as the main entry method
 * for routing.
 *
 **********************************************************************/

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>


#include "sr_if.h"
#include "sr_rt.h"
#include "sr_router.h"
#include "sr_protocol.h"
#include "sr_arpcache.h"
#include "sr_utils.h"

/*---------------------------------------------------------------------
 * Method: sr_init(void)
 * Scope:  Global
 *
 * Initialize the routing subsystem
 *
 *---------------------------------------------------------------------*/

void sr_init(struct sr_instance* sr)
{
    /* REQUIRES */
    assert(sr);

    /* Initialize cache and cache cleanup thread */
    sr_arpcache_init(&(sr->cache));

    pthread_attr_init(&(sr->attr));
    pthread_attr_setdetachstate(&(sr->attr), PTHREAD_CREATE_JOINABLE);
    pthread_attr_setscope(&(sr->attr), PTHREAD_SCOPE_SYSTEM);
    pthread_attr_setscope(&(sr->attr), PTHREAD_SCOPE_SYSTEM);
    pthread_t thread;

    pthread_create(&thread, &(sr->attr), sr_arpcache_timeout, sr);
    
    /* Add initialization code here! */

} /* -- sr_init -- */

/*---------------------------------------------------------------------
 * Method: sr_handlepacket(uint8_t* p,char* interface)
 * Scope:  Global
 *
 * This method is called each time the router receives a packet on the
 * interface.  The packet buffer, the packet length and the receiving
 * interface are passed in as parameters. The packet is complete with
 * ethernet headers.
 *
 * Note: Both the packet buffer and the character's memory are handled
 * by sr_vns_comm.c that means do NOT delete either.  Make a copy of the
 * packet instead if you intend to keep it around beyond the scope of
 * the method call.
 *
 *---------------------------------------------------------------------*/

void sr_handlepacket(struct sr_instance* sr,
        uint8_t * packet/* lent */,
        unsigned int len,
        char* interface/* lent */)
{
  /* REQUIRES */
  assert(sr);
  assert(packet);
  assert(interface);

  printf("*** -> Received packet of length %d \n",len);
  
  uint16_t ethernet_type = ethertype(packet);
  unsigned int ether_len = sizeof(sr_ethernet_hdr_t);
  
  if (len < ether_len) {
	  fprintf(stderr, "Invalid Ethernet Header Size");
	  exit(0);
  }
  
  if (ethernet_type == ethertype_arp) {
	  printf("Received an ARP Packet\n");
	  sr_arp_handler(sr, packet, len, interface);
  } else if (ethernet_type == ethertype_ip) {
	  printf("Received an IP Packet\n");
	  sr_ip_handler(sr, packet, len, interface);
  } else {
	  printf("Unrecognized Ethernet Type\n"); /*ignore packet*/
  }

}/* end sr_ForwardPacket */

/*
 * This returns a interface record of our router if the given ip
 * matches the ip of the record, returns NULL if it matches with 
 * none of the router's interfaces
 */
struct sr_if * sr_get_interface_ip(struct sr_instance *sr, uint32_t ip) {
	struct sr_if *curr_iface = sr->if_list;
	while(curr_iface) {
		if (ip == curr_iface->ip) {
			return curr_iface;
		}
		
		curr_iface = curr_iface->next;
	}
	
	return NULL;
}


/*
 * return lpm sr_rt if destination ip is in the routing table, or NULL
 * if there is not destination in the table that matches the packets destination
 */
struct sr_rt *longest_prefix_match(struct sr_instance *sr, uint32_t ip) {
	struct sr_rt *lpm_entry = NULL; /*initialize lpm entry*/
	struct sr_rt *curr_entry = sr->routing_table;
	unsigned long int lm = 0;
	
	/*search routing table for lpm entry*/
	while (curr_entry) {
		if ((curr_entry->mask.s_addr & ip) == curr_entry->dest.s_addr) {
			if(curr_entry->mask.s_addr > lm) {
				lpm_entry = curr_entry;
				lm = curr_entry->mask.s_addr;
			}
			
		}
		
		curr_entry = curr_entry->next;
	}
	
	return lpm_entry;
}

int sr_send_arp(struct sr_instance *sr, unsigned short ar_op, unsigned char ar_thrda[ETHER_ADDR_LEN], uint32_t ar_tip) {
	unsigned len_arp = sizeof(sr_ethernet_hdr_t) + sizeof(sr_arp_hdr_t);
	uint8_t *new_pkt = (uint8_t *) malloc(len_arp);
	
	memset(new_pkt, 0, len_arp); /*reassure the value is properly initialized*/
	
	struct sr_rt *gw_entry = longest_prefix_match(sr, ar_tip);
	
	if (gw_entry) {
		struct sr_if *out_iface = sr_get_interface(sr, gw_entry->interface);
		
		/*Set Ethernet Header/Frame*/
		sr_ethernet_hdr_t *ether_hdr = (sr_ethernet_hdr_t *) new_pkt;
		if (ar_op == arp_op_request) {
			printf("Preparing to Send ARP Request...\n");
			memset(ether_hdr->ether_dhost, 0xff, ETHER_ADDR_LEN);
		}else {
			printf("Preparing to Send ARP Reply...\n");
			memcpy(ether_hdr->ether_dhost, ar_thrda, ETHER_ADDR_LEN);
		}
		
		memcpy(ether_hdr->ether_shost, out_iface->addr, ETHER_ADDR_LEN);
		ether_hdr->ether_type = htons(ethertype_arp);
		
		/* Set ARP Header */
		sr_arp_hdr_t *arp_hdr = (sr_arp_hdr_t *) (new_pkt + sizeof(sr_ethernet_hdr_t));
		
		arp_hdr->ar_hln = ETHER_ADDR_LEN;
		arp_hdr->ar_hrd = htons(arp_hrd_ethernet);
		arp_hdr->ar_op = htons(ar_op);
		arp_hdr->ar_pln = 4;
		arp_hdr->ar_pro = htons(ethertype_ip);
		
		memcpy(arp_hdr->ar_sha, out_iface->addr, ETHER_ADDR_LEN);
		arp_hdr->ar_sip = out_iface->ip;
		memcpy(arp_hdr->ar_tha, ar_thrda, ETHER_ADDR_LEN);
		arp_hdr->ar_tip = ar_tip;
		
		printf("Sending ARP Packet\n");
		
		sr_send_packet(sr, new_pkt, len_arp, gw_entry->interface);
		free(new_pkt);
		return 0;
		
	}else {
		fprintf(stderr, "Can't Send ARP Packet\n");
		free(new_pkt);
		return -1;
	}
			
}

int sr_arp_handler(struct sr_instance *sr, uint8_t *packet, unsigned int len, char *interface) {
	
	int arp_len = (sizeof(sr_ethernet_hdr_t) + sizeof(sr_arp_hdr_t));
	
	if (len < arp_len) {
		fprintf(stderr, "Invalid ARP Packet Length");
		return -1;
	}
	
	sr_arp_hdr_t *arp_hdr = (sr_arp_hdr_t *) (packet + sizeof(sr_ethernet_hdr_t));
	
	struct sr_if *target_iface = sr_get_interface_ip(sr, arp_hdr->ar_tip);
	
	
	if (!target_iface) {
		fprintf(stderr, "ARP Packet not for this router\n");
		return -1;
		
	}else {
	
		/*Check if the ARP Packet is a Request or Reply*/
		if(arp_hdr->ar_op == htons(arp_op_request)) {
			printf("Sending ARP Reply\n");
			sr_send_arp(sr, arp_op_reply, arp_hdr->ar_sha, arp_hdr->ar_sip);
			
			return 0;
		}else {/* its a reply */
			
			/*Insert new IP->MAC Mapping in cache*/
			struct sr_arpreq *req = sr_arpcache_insert(&(sr->cache), arp_hdr->ar_sha, arp_hdr->ar_sip);
			
			struct sr_packet *pkts = req->packets;
			
			printf("*** -> Reply Received, Preparing to send all packets on queue...\n");
			while (pkts) {
				
				/*set ethernet header with replyed address*/
				sr_ethernet_hdr_t *ether_hdr = (sr_ethernet_hdr_t *) pkts->buf;
				
				struct sr_if *out_iface = sr_get_interface(sr, interface);
				
				memcpy(ether_hdr->ether_dhost, arp_hdr->ar_sha, ETHER_ADDR_LEN);
				memcpy(ether_hdr->ether_shost, out_iface->addr, ETHER_ADDR_LEN);
				
				sr_ip_hdr_t *ip_hdr = (sr_ip_hdr_t *) (pkts->buf + sizeof(sr_ethernet_hdr_t));
				
				/*Update IP header*/
				ip_hdr->ip_ttl -= 1;
				ip_hdr->ip_sum = 0; /* in order to recalculate checksum*/
				ip_hdr->ip_sum = cksum(ip_hdr, (ip_hdr->ip_hl * 4));
					
				/*send packet*/
				sr_send_packet(sr, pkts->buf, pkts->len, interface);
				
				/*move on to next packet in the queue*/
				pkts = pkts->next;
			}
			
			printf("All Packets on request queue have been sent\n");
			
			sr_arpreq_destroy(&(sr->cache), req);
			
			return 0;
			
		}
	}
}

/*
 * This will be used to create different types of ICMP packets and send them
 */
int sr_send_icmp(struct sr_instance *sr, uint8_t *packet, char *interface, uint8_t type, uint8_t code) {
	/*create ICMP packet of certain type and code*/
	
	size_t icmp_hdr_size = 0;
	
	sr_ip_hdr_t *ip_hdr_old = (sr_ip_hdr_t *) (packet + sizeof(sr_ethernet_hdr_t));
	
	if (type == 0) {
		icmp_hdr_size = ntohs(ip_hdr_old->ip_len) - (ip_hdr_old->ip_hl * 4);
	} else if (type == 3 || type == 11) {
		icmp_hdr_size = sizeof(sr_icmp_t3_hdr_t);
	} else {
		fprintf(stderr, "ICMP type not recognized\n");
		return -1;
	}
	
	unsigned int icmp_len = icmp_hdr_size + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t);
	
	uint8_t *new_pkt = (uint8_t *) malloc(icmp_len);
	memset(new_pkt, 0, icmp_len);
	
	struct sr_if *out_iface = sr_get_interface(sr, interface);
	
	/*Set Ethernet Header*/
	sr_ethernet_hdr_t *ether_hdr = (sr_ethernet_hdr_t *) new_pkt;
	sr_ethernet_hdr_t *ether_hdr_old = (sr_ethernet_hdr_t *) packet;
	memcpy(ether_hdr->ether_dhost, ether_hdr_old->ether_shost, ETHER_ADDR_LEN);
	memcpy(ether_hdr->ether_shost, ether_hdr_old->ether_dhost, ETHER_ADDR_LEN);
	ether_hdr->ether_type = htons(ethertype_ip);
	
	/*Set IP Header*/
	sr_ip_hdr_t *ip_hdr = (sr_ip_hdr_t *) (new_pkt + sizeof(sr_ethernet_hdr_t));
	ip_hdr->ip_dst = ip_hdr_old->ip_src;
	ip_hdr->ip_hl = 5;
	ip_hdr->ip_id = htons(0);
	ip_hdr->ip_p = ip_protocol_icmp;
	ip_hdr->ip_src = out_iface->ip;
	ip_hdr->ip_tos = 0;
	ip_hdr->ip_off = htons(IP_DF);
	ip_hdr->ip_ttl = INIT_TTL;
	ip_hdr->ip_v = 4;
	
	/*Set ICMP Header*/
	
	if (type == 0) {
		sr_icmp_t0_hdr_t *icmp_hdr_old = (sr_icmp_t0_hdr_t *) (packet + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t));
		sr_icmp_t0_hdr_t *icmp_hdr = (sr_icmp_t0_hdr_t *) (new_pkt + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t));
		icmp_hdr->icmp_code = code;
		icmp_hdr->icmp_type = type;
		icmp_hdr->identifier = icmp_hdr_old->identifier;
		icmp_hdr->sequence_number = icmp_hdr_old->sequence_number;
		icmp_hdr->timestamp = icmp_hdr_old->timestamp;
		memcpy(icmp_hdr->data, icmp_hdr_old->data, icmp_hdr_size - ICMP_ZERO_HEADER_SIZE);
		
		icmp_hdr->icmp_sum = cksum(icmp_hdr, icmp_hdr_size);
		
		ip_hdr->ip_len = htons(20 + icmp_hdr_size);
		ip_hdr->ip_sum = cksum(new_pkt + sizeof(sr_ethernet_hdr_t), (ip_hdr->ip_hl * 4));
			
		printf("Sending ICMP echo Reply\n");
		sr_send_packet(sr, new_pkt, icmp_len, interface);
		
	} else if (type == 3 || type == 11) {
		sr_icmp_t3_hdr_t *icmp_t3_hdr = (sr_icmp_t3_hdr_t *) (new_pkt + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t));
		icmp_t3_hdr->icmp_code = code;
		icmp_t3_hdr->icmp_type = type;
		memcpy(icmp_t3_hdr->data, packet + sizeof(sr_ethernet_hdr_t), ICMP_DATA_SIZE);
		icmp_t3_hdr->icmp_sum = cksum(icmp_t3_hdr, icmp_hdr_size);
		
		ip_hdr->ip_len = htons(20 + icmp_hdr_size);
		ip_hdr->ip_sum = cksum(ip_hdr, (ip_hdr->ip_hl * 4));
		
		printf("Sending ICMP error message\n");
		sr_send_packet(sr, new_pkt, icmp_len, interface);
		printf("Message Sent\n");
	}

	free(new_pkt);
	
	return 0;
	
}

int icmp_handler(struct sr_instance *sr, sr_ip_hdr_t *ip_hdr, sr_ethernet_hdr_t *ether_hdr, unsigned int len, char *interface) {
	if (ip_hdr->ip_p == ip_protocol_icmp) {
		sr_icmp_hdr_t *icmp_hdr = (sr_icmp_hdr_t *) (ip_hdr + sizeof(sr_ip_hdr_t));
		if(icmp_hdr->icmp_type == 0 && icmp_hdr->icmp_code == 0) {
			printf("Received ICMP echo request\n");
			sr_send_icmp(sr, (uint8_t *) ether_hdr, interface, 0, 0);
			return 0;
			
			
		} else {
			printf("Unrecognized ICMP Packet\n"); /*ignore*/
			return -1;
		}
		
		
	} else if(ip_hdr->ip_p == 0x0006 || ip_hdr->ip_p == 0x0011) {
		printf("TCP or UDP protocol detected, Sending ICMP port unreachable\n");
		sr_send_icmp(sr, (uint8_t *) ether_hdr, interface, 3, 3);
		return 0;
		
	} else { /* unrecognized protocol */
		printf("Unrecognized protocol, ignoring packet\n");
		return -1;
	}
	
}


int forward_pkt(struct sr_instance *sr, sr_ip_hdr_t *ip_hdr, sr_ethernet_hdr_t *ether_hdr, unsigned int len, char *interface) {
	
	uint8_t *packet = (uint8_t *) ether_hdr;
	
	
	/*check if ttl is 1 or below*/
	if (ip_hdr->ip_ttl <= 1) {
		fprintf(stderr, "TTL Exceeded.\n");
		sr_send_icmp(sr, (uint8_t *) ether_hdr, interface, 11, 0);
		return 1;
	}
	
	struct sr_rt *lpm_entry = longest_prefix_match(sr, ip_hdr->ip_dst);
	
	/*check if destination IP is reachable*/
	if (!lpm_entry) {
		fprintf(stderr, "Net Unreachable.\n");
		sr_send_icmp(sr, (uint8_t *) ether_hdr, interface, 3, 0);
		return 1;
	}
	
	struct sr_if *out_iface = sr_get_interface(sr, lpm_entry->interface);

	/*set ethernet source host address*/
	memcpy(ether_hdr->ether_shost, out_iface->addr, ETHER_ADDR_LEN);

	/*lookup next-hop MAC address in arpcache using next-hop IP*/
	struct sr_arpentry *arp_entry = sr_arpcache_lookup(&(sr->cache), lpm_entry->gw.s_addr);

	if (arp_entry) {
		/* set ethernet destination host address */
		memcpy(ether_hdr->ether_dhost, arp_entry->mac, ETHER_ADDR_LEN);
		free(arp_entry);

		/* Update IP header */
		ip_hdr->ip_ttl -= 1;
		ip_hdr->ip_sum = 0; /*in order to recalculate checksum*/
		ip_hdr->ip_sum = cksum(ip_hdr, (ip_hdr->ip_hl * 4));

		/* send packet to next-hop MAC address */
		printf("Sending Packet -> ***\n");
		sr_send_packet(sr, packet, len, lpm_entry->interface);

	} else {
		struct sr_arpreq *req= sr_arpcache_queuereq(&(sr->cache), lpm_entry->gw.s_addr, packet, len, interface);
		handle_arpreq(sr, req);
	}
	
	return 0;
	
}


int sr_ip_handler(struct sr_instance *sr, uint8_t *packet, unsigned int len, char *interface) {
	/*check packet length*/
	
	int ip_len = sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t);
	
	if (len < ip_len) {
		fprintf(stderr, "Invalid IP Packet length\n");
		return -1;
	}
	
	/*pointers to each header of the packet*/
	sr_ethernet_hdr_t *ether_hdr = (sr_ethernet_hdr_t *) packet;
	sr_ip_hdr_t *ip_hdr = (sr_ip_hdr_t *) (packet + sizeof(sr_ethernet_hdr_t));
	
	/*verify IP cksm*/
	if (!cksum(ip_hdr, ip_hdr->ip_hl)) {
		fprintf(stderr, "Invalid IP header checksum\n");
		return -1;
	}
	
	
	struct sr_if *target_iface = sr_get_interface_ip(sr, ip_hdr->ip_dst);
	/* determine if target ip is for this router or not */
	if (!target_iface) {
		/*send it to packet forwarding method*/
		printf("*** -> IP Packet is not for us, Forwarding...\n");
		forward_pkt(sr, ip_hdr, ether_hdr, len, interface);	
	}else {
		/*send it to ICMP handler*/ 
		icmp_handler(sr, ip_hdr, ether_hdr, len, interface);
	}
	
	return 0;	
			
}




