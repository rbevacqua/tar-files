void my_sort(Record *, int, size_t);

int compare (const void *, const void *);