#include "utils.h"
#include "my_sort.h"
 
int main(int argc, char *argv[]) {

	if (argc != 5) {
		printf("Error: not the right amount of arguments\n");
		exit(-1);
	}

	
	int fd = open(argv[1], O_RDONLY);
	int fd_out = open("temp.dat", O_WRONLY | O_CREAT, 0666);
	int runs = atoi(argv[4]);
	int block_size = atoi(argv[3]);
	InputBuffer in_buffers[runs];



	/*Get file length*/
	int file_len = lseek(fd, 0, SEEK_END);

	/*blocks in file*/
	int blocks_in_file = file_len/block_size;

	if (file_len % block_size > 0) { 
		blocks_in_file += 1;
	}

	/*max runs based on allocated memory*/
	int min_runs = file_len/atoi(argv[2]);

	if ((file_len % atoi(argv[2])) != 0) {
		min_runs += 1;
	}

	/*Reset position of fd*/
	lseek(fd, 0, SEEK_SET); 

	if (runs < min_runs) {
		printf("Error: insufficient amount of memory for %d runs\n", atoi(argv[4]));
		exit(-1);
	}

	int recs_per_block = block_size/sizeof(Record);
	int extra_blocks = blocks_in_file % runs;
	int blocks_per_run = blocks_in_file / runs;
	
	if (extra_blocks > 0) {
		blocks_per_run += 1;
		extra_blocks -= 1;

		if (extra_blocks == 0) {
			extra_blocks -= 1;
		}
	}

	Record *mm = (Record *) malloc(atoi(argv[2]));
	int total_blocks = 0;
	int i, n, cur_run;
	cur_run = 0;

	while(total_blocks != blocks_in_file) {
		
		n = 0;
		char *in = (char *)mm;
		for(i = 0; i < blocks_per_run; i++) {
			n += read(fd, in + (i * block_size), block_size);

		}
		

		my_sort(mm, blocks_per_run * recs_per_block, sizeof(Record));

		/*Fill in inputbuffer info here, during each run in phase1*/
		in_buffers[cur_run].runLength = n;
		
		if (cur_run == 0) {
			in_buffers[cur_run].currentPositionInFile = 0;
		}
		else if (cur_run > 0) {
			in_buffers[cur_run].currentPositionInFile = in_buffers[cur_run-1].currentPositionInFile + in_buffers[cur_run-1].runLength;
		}

		i = 0;

		
		while (i < n) {
			
			if (n - i < block_size) {
				i += write(fd_out, in + i, n-i);
			} else {
				i += write(fd_out, in + i, block_size);
			}

		}

		total_blocks += blocks_per_run;

		/*Used to balance the amount of blocks in each run*/
		if (extra_blocks > 0) {
			extra_blocks -= 1;

			if (extra_blocks == 0) {
				extra_blocks -= 1;
			}
		} else if (extra_blocks == -1) {
			blocks_per_run -= 1;
			extra_blocks = 0;
		}

		cur_run++;

	}

	close(fd);
	close(fd_out);

	memset(mm, 0, atoi(argv[2]));

	/*begin phase 2*/

	phase2(mm, runs, block_size, atoi(argv[2]), in_buffers);

	return 0;
}

int phase2(Record *mm, int runs, int block_size, int mem_size, InputBuffer *in_buffers) {

	MergeManager merger;
	HeapRecord hrecord;
	Record rec;
	merger.outputFP = fopen("sorted_edges.dat", "w");
	HeapRecord heap[runs];
	merger.heap = heap;
	merger.heapSize = 0;
	merger.heapCapacity = runs;
	merger.inputBuffers = in_buffers;
	
	initInputBuffers(&merger, runs, block_size, mem_size, mm);
	initHeap(&merger, runs);
	
	while (merger.heapSize > 0) {
		
		getTopHeapElement(&merger, &hrecord);
		
		merger.heapSize--;

		rec.uid1 = hrecord.uid1;
		rec.uid2 = hrecord.uid2;

		addToOutputBuffer(&merger, &rec);

		if (merger.inputBuffers[hrecord.run_id].done == 0) {
			if (getNextRecord(&merger, hrecord.run_id, &rec) == 0) {

				hrecord.uid1 = rec.uid1;
				hrecord.uid2 = rec.uid2;
				
				insertIntoHeap(&merger, hrecord.run_id, &hrecord);
			}
		}
	}

	flushOutputBuffer(&merger);

	fclose(merger.outputFP);
	
	
	return 0;
}

int initHeap(MergeManager *merger, int runs) {
	int i;
	HeapRecord hrecord;
	for (i=0;i<runs;i++) {
		hrecord.uid1 = merger->inputBuffers[i].buffer[0].uid1;
		hrecord.uid2 = merger->inputBuffers[i].buffer[0].uid2;
		insertIntoHeap(merger, i, &hrecord);

	}
	return 0;
}

int initInputBuffers(MergeManager *merger, int runs, int block_size, int mem_size, Record *mm) {
	int i, n;
	merger->inputFP = fopen("temp.dat", "r");
	int blocks_per_buffer = (mem_size/(runs+1))/block_size;
	for (i = 0; i < runs; i++) {
		merger->inputBuffers[i].capacity = blocks_per_buffer * (block_size/sizeof(Record));
		if (i == 0) {
			merger->inputBuffers[i].buffer = mm;
		} else {
			merger->inputBuffers[i].buffer = mm + (merger->inputBuffers[i-1].capacity * i);
		}
		fseek(merger->inputFP, merger->inputBuffers[i].currentPositionInFile, SEEK_SET);
		n = fread(merger->inputBuffers[i].buffer, sizeof(Record), merger->inputBuffers[i].capacity, merger->inputFP);
		
		merger->inputBuffers[i].done = 0;
		merger->inputBuffers[i].totalElements = n;
		merger->inputBuffers[i].currentBufferPosition = 0;
		merger->inputBuffers[i].currentPositionInFile += (n*sizeof(Record));
		merger->inputBuffers[i].runLength -= (n*sizeof(Record));
	}

	/*close input file and reopen later to refill any inputbuffers*/

	/*init OutputBuffer aswell*/
	merger->outputBufferCapacity = blocks_per_buffer * (block_size/sizeof(Record));
	merger->outputBuffer = mm + (merger->outputBufferCapacity * runs);
	merger->currentPositionInOutputBuffer = 0;

	fclose(merger->inputFP);
	return 0;
}

int getTopHeapElement (MergeManager *merger, HeapRecord *result) {
	HeapRecord item;
	int child, parent;

	if(merger->heapSize == 0) {
		printf( "UNEXPECTED ERROR: popping top element from an empty heap\n");
		return 1;
	}

	*result=merger->heap[0];  //to be returned

	//now we need to reorganize heap - keep the smallest on top
	item = merger->heap[merger->heapSize-1]; // to be reinserted 

	parent=0;

	while ((child = (2 * parent) + 1) < merger->heapSize) {
		// if there are two children, compare them 
		if (child + 1 < merger->heapSize && (compare((void *)&(merger->heap[child]),(void *)&(merger->heap[child + 1]))>0)) {
			++child;
		}
		// compare item with the larger 
		if (compare((void *)&item, (void *)&(merger->heap[child]))>0) {
			merger->heap[parent] = merger->heap[child];
			parent = child;
		} else {
			break;
		}
	}
	merger->heap[parent] = item;
	
	return 0;
}

int insertIntoHeap (MergeManager *merger, int run_id, HeapRecord *hrecord) {
	hrecord->run_id = run_id;

	int child, parent;
	if (merger->heapSize == merger->heapCapacity)	{
		printf( "Unexpected ERROR: heap is full\n");
		return 1;
	}	
  	
	child = merger->heapSize++; /* the next available slot in the heap */
	
	while (child > 0)	{
		parent = (child - 1) / 2;
		if (compare((void *)&(merger->heap[parent]),(void *)hrecord)>0) {
			merger->heap[child] = merger->heap[parent];
			child = parent;
		} else 	{
			break;
		}
	}
	merger->heap[child]=*hrecord;	
	return 0;
}

int getNextRecord(MergeManager *merger, int run_id, Record *record) {
	InputBuffer *in_buff = &merger->inputBuffers[run_id];
	in_buff->currentBufferPosition++;
	int pos = in_buff->currentBufferPosition;

	if (pos == in_buff->totalElements) {
		if (refillBuffer(merger, run_id) == 0) {
			record->uid1 = in_buff->buffer[0].uid1;
			record->uid2 = in_buff->buffer[0].uid2;
		} else {
			return 1;
		}

	} else {
		record->uid1 = in_buff->buffer[pos].uid1;
		record->uid2 = in_buff->buffer[pos].uid2;
	}

	return 0;
}

int addToOutputBuffer(MergeManager *merger, Record *record) {

	if (merger->currentPositionInOutputBuffer == merger->outputBufferCapacity) {
		/*buffer is full write and flush to disk*/
		flushOutputBuffer(merger);
		merger->currentPositionInOutputBuffer = 1;
		merger->outputBuffer[0] = *record;

	} else {
		merger->outputBuffer[merger->currentPositionInOutputBuffer] = *record;
		merger->currentPositionInOutputBuffer++;
	}

	return 0;
	
}

int refillBuffer(MergeManager *merger, int run_id) {
	merger->inputFP = fopen("temp.dat", "r");
	InputBuffer *in_buff = &merger->inputBuffers[run_id];
	int n;

	if (in_buff->runLength == 0) {
		in_buff->done = 1;
		fclose(merger->inputFP);

		return 1;
	}

	if (in_buff->runLength >= (int)(in_buff->capacity*sizeof(Record))) {
		fseek(merger->inputFP, in_buff->currentPositionInFile, SEEK_SET);
		n = fread(in_buff->buffer, sizeof(Record), in_buff->capacity, merger->inputFP);
		in_buff->totalElements = n;
		in_buff->currentBufferPosition = 0;
		in_buff->currentPositionInFile += (n*sizeof(Record));
		in_buff->runLength -= (n*sizeof(Record));


	} else if (in_buff->runLength < (int)(in_buff->capacity*sizeof(Record))) {
		fseek(merger->inputFP, in_buff->currentPositionInFile, SEEK_SET);
		n = fread(in_buff->buffer, sizeof(Record), in_buff->runLength/sizeof(Record), merger->inputFP);
		in_buff->totalElements = n;
		in_buff->currentBufferPosition = 0;
		in_buff->currentPositionInFile += (n*sizeof(Record));
		in_buff->runLength -= (n*sizeof(Record));

	}


	fclose(merger->inputFP);

	return 0;
	
}

int flushOutputBuffer(MergeManager *merger) {
	
	int pos = merger->currentPositionInOutputBuffer;
	fwrite(merger->outputBuffer, sizeof(Record), pos, merger->outputFP);
	fflush(merger->outputFP);

	return 0;
}