#include "utils.h"

int compare (const void *a, const void *b) {
	int a_uid2 = ((Record *)a)->uid2;
	int b_uid2 = ((Record *)b)->uid2;

	return (a_uid2 - b_uid2);
}

void my_sort(Record *buffer, int total_records, size_t record_size) {

	qsort(buffer, total_records, record_size, compare);
}
